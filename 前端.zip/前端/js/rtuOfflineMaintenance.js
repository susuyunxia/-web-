//全局变量
var configNo = '';
var serial = '';
var params={};
var userNO='Admin'

$(function () {
    //获取用户信息
    // buss.getUserInfo();
    if(userNO!=''){
        getConfigName();
        //点击确定提交表单
        $('#btnConfig').on('click',function () {
            //获取rtu掉线的相关参数值;
            params.configName='RTU掉线';
            params.dayValue=$('.rtuVal').val();
            params.userNo= userNO;
            $.ajax({
                type: "post",
                url: javaUrlBase + '/config/updateRTUConfig.do',
                data: params,
                dataType: "json",
                success: function (response) {
                    if(response){
                        alert(response.message);
                    }
                },
                error:function () {
                    alert('shax');
                }
            });
        })
    }
})
//获取异常类型
function getConfigName() {
    $.ajax({
        url: javaUrlBase + '/config/getConfiurationTree.do',
        type: 'post',
        data: {},
        dataType: 'json',
        success: function (data) {
            if (data) {
                $(data).each(function (i, v) {
                    if (v.configName == "RTU掉线维护") {
                        configNo = v.configNo;
                        $.ajax({
                            url: javaUrlBase + "/config/getConfigurationByConfigNo.do",
                            type: 'post',
                            data: { "configNo": configNo },
                            dataType: 'json',
                            success: function (data) {
                                $(data.rows).each(function(i,v){
                                    $('.rtuVal').val(v.fieldDayValue);
                                    params.serial=v.serial;//（主键编号）
                                    params.configNo=configNo;//（异常编号）
                                })


                            },
                            error: function () {
                                console.log('222');
                            }
                        })
                    }
                })
            }

            //处理返回数据
        },
        error: function () {
            console.log('eee');
        }
    })
    //请求数据
}



