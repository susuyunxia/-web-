//全局变量初始化
var configNo = '', page = 0, rows = '';
//配置雨量异常参数
var serial = '', dayValue = 0, fieldValue = '', param = {};
$(function () {
    //获取用户信息
    buss.getUserInfo();
    //读取雨量异常配置
    rainFall();
    //提交表单
    $('.button').on('click', function () {
        param.dayValue = $('#tian').val();//输入的雨量(天);
        param.fieldValue = $('#mi').val()//输入的雨量(米);
        param.userNo = userNO;
        $.ajax({
            url: javaUrlBase + '/config/upadtePJException.do',
            type: 'post',
            dataType: 'json',
            data: param,
            success: function (response) {
                console.log(response)
                if (response) {
                    alert(response.message);
                }
            },
            error: function () {
                console.log('sss')
            }
        })

    })
})
//雨量异常配置
function rainFall() {
    $.ajax({
        url: javaUrlBase + '/config/getConfiurationTree.do',
        type: 'post',
        dataType: 'json',
        data: {},
        success: function (data) {
            console.log(data);
            if (data) {
                $(data).each(function (i, v) {
                    if (v.configName == '雨量维护') {
                        configNo = v.configNo;
                        //去读数据
                        $.ajax({
                            url: javaUrlBase + "/config/getConfigurationByConfigNo.do",
                            type: 'post',
                            dataType: 'json',
                            data: { configNo: configNo },
                            success: function (data) {
                                $(data.rows).each(function (i, v) {
                                    if (v.configNo == configNo) {
                                        param.serial = v.serial;//主键
                                        param.configNo = v.configNo;//（异常编号）
                                        param.configName = '雨量维护';//（异常编号）
                                        $('#tian').val(v.fieldDayValue);
                                        $('#mi').val(v.fieldValue);
                                    }
                                })
                            },
                            error: function () {

                            }
                        });
                    }
                })
            }
        }
    })
}