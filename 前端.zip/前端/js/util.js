//获取当前时间
function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate

    return currentdate;
}
//获取当前时间的前3天时间
function getThreeDaysBeforeDate() {
    var seperator1 = "-";
    var seperator2 = ":";
    var date = new Date(),
        timestamp, newDate;

    timestamp = date.getTime();

    // 获取三天前的日期
    newDate = new Date(timestamp - 3 * 24 * 3600 * 1000);

    var year = newDate.getFullYear();

    // 月+1是因为js中月份是按0开始的
    var month = newDate.getMonth() + 1;

    var day = newDate.getDate();

    if (day < 10) { // 如果日小于10，前面拼接0

        day = '0' + day;
    }

    if (month < 10) { // 如果月小于10，前面拼接0

        month = '0' + month;
    }
    currentbefore3 = year + seperator1 + month + seperator1 + day
    return currentbefore3;

}
//获取当前时间
function getNowFormatDate2() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    var hours = date.getHours();
    var Minutes = date.getMinutes();
    var Seconds = date.getSeconds();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    if (hours >= 0 && hours <= 9) {
        hours = "0" + hours;
    }
    if (Minutes >= 0 && Minutes <= 9) {
        Minutes = "0" + Minutes;
    }
    if (Seconds >= 0 && Seconds <= 9) {
        Seconds = "0" + Seconds;
    }

    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate +
        " " + hours + seperator2 + Minutes +
        seperator2 + Seconds;
    return currentdate;
}
//获取当前时间的前3天时间
function getThreeDaysBeforeDate2() {
    var seperator1 = "-";
    var seperator2 = ":";
    var date = new Date(),
        timestamp, newDate;

    timestamp = date.getTime();

    // 获取三天前的日期
    newDate = new Date(timestamp - 3 * 24 * 3600 * 1000);

    var year = newDate.getFullYear();

    // 月+1是因为js中月份是按0开始的
    var month = newDate.getMonth() + 1;

    var day = newDate.getDate();

    var hours = date.getHours();
    var Minutes = date.getMinutes();
    var Seconds = date.getSeconds();
    if (day >= 0 && day <= 9) {
        day = "0" + day;
    }
    if (month >= 0 && month <= 9) {
        month = "0" + month;
    }

    if (hours >= 0 && hours <= 9) {
        hours = "0" + hours;
    }
    if (Minutes >= 0 && Minutes <= 9) {
        Minutes = "0" + Minutes;
    }
    if (Seconds >= 0 && Seconds <= 9) {
        Seconds = "0" + Seconds;
    }

    currentbefore3 = year + seperator1 + month + seperator1 + day +
        " " + hours + seperator2 + Minutes +
        seperator2 + Seconds;
    return currentbefore3;

}
function getNowFormatDate3() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    var hours = date.getHours();
    var Minutes = date.getMinutes();
    var Seconds = date.getSeconds();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    if (hours >= 0 && hours <= 9) {
        hours = "0" + hours;
    }
    if (Minutes >= 0 && Minutes <= 9) {
        Minutes = "0" + Minutes;
    }
   

    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate +
        " " + hours + seperator2 + Minutes 
    return currentdate;
}
//获取当前时间的前3天时间
function getThreeDaysBeforeDate3() {
    var seperator1 = "-";
    var seperator2 = ":";
    var date = new Date(),
        timestamp, newDate;

    timestamp = date.getTime();

    // 获取三天前的日期
    newDate = new Date(timestamp - 3 * 24 * 3600 * 1000);

    var year = newDate.getFullYear();

    // 月+1是因为js中月份是按0开始的
    var month = newDate.getMonth() + 1;

    var day = newDate.getDate();

    var hours = date.getHours();
    var Minutes = date.getMinutes();
    var Seconds = date.getSeconds();
    if (day >= 0 && day <= 9) {
        day = "0" + day;
    }
    if (month >= 0 && month <= 9) {
        month = "0" + month;
    }

    if (hours >= 0 && hours <= 9) {
        hours = "0" + hours;
    }
    if (Minutes >= 0 && Minutes <= 9) {
        Minutes = "0" + Minutes;
    }
    

    currentbefore3 = year + seperator1 + month + seperator1 + day +
        " " + hours + seperator2 + Minutes 
    return currentbefore3;

}


    //获取url中的对象;
    function UrlSearch() {
        var name, value;
        var str = location.href; //取得整个地址栏
        var num = str.indexOf("?")
        str = str.substr(num + 1); //取得所有参数   stringvar.substr(start [, length ]

        var arr = str.split("&"); //各个参数放到数组里
        for (var i = 0; i < arr.length; i++) {
            num = arr[i].indexOf("=");
            if (num > 0) {
                name = arr[i].substring(0, num);
                value = arr[i].substr(num + 1);
                this[name] = value;
            }
        }
    }
