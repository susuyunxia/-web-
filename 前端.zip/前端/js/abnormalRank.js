//站点编号
var siteNO = "1703230812";
//开始时间
var startTime = "";
//结束时间
var endTime = "";

$(function () {
    //获取站点的排行数据
    var list = getSiteRank();
    //渲染列表
    renderList(list)
});

//获取站点的排行数据
function getSiteRank() {
    var params = {
        "siteNo": siteNO,
        "startTime": startTime,
        "endTime": endTime
    };
    $.ajax({
        type: "post",
        url: javaUrlBase + "/backstage/getAlarmOrderBySiteNo.do",
        data: params,
        async: false,
        dataType: "json",
        success: function (response) {
            if (response) {
                return response;
            } else {
                alert("服务异常，请联系管理员");
            }
        }
    });
}

//渲染工单列表
function renderList(list) {
    $(list).each(function (i, e) {
        renderCount(e.configName, e.count);
    });
}

//修改异常因子次数
function renderCount(configName, value) {
    switch (configName) {
        case "同一站点数据无变化维护":
            $("#yzwbh").text(value);
            break;
        case "雨量维护":
            $("#ylyc").text(value);
            break;
        case "流量维护":
            $("#llyc").text(value);
            break;
        case "水位计跳动维护":
            $("#swjtd").text(value);
            break;
        case "RTU掉线维护":
            $("#rtudx").text(value);
            break;
    }
}