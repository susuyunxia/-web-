$(function () {
    //获取用户信息
    buss.getUserInfo();
    if (userNO != "") {
        //获取用户工单
        var list = getUserDispach();
    }

    //绑定项目
    $(document).on("click",".each",jumpToMap);
});

//获取用户工单
function getUserDispach() {
    var params = {
        userNo: userNO
    };

    $.ajax({
        type: "post",
        url: "http://192.168.16.44:8002/backstageMaintain/selectSignedByUserNo.do",
        data: params,
        dataType: "json",
        success: function (response) {
            if (response) {
                var html = template("dispatchList", { "item": response });
                $(".root").html(html);
            } else {
                alert("服务异常，请联系管理员");
            }
        }
    });
}

//页面跳转
function jumpToMap(){
    var routingId = $(this).data("routingid");
    var pointX = $(this).data("pointx");
    var pointY = $(this).data("pointy");
    var address = $(this).data("address");
    var siteNo = $(this).data("siteno");
    var siteName = $(this).data("sitename");

    window.location.href = "inspectionMap.html?"+encodeURI("routingId="+routingId+"&PointX="+pointX+"&PointY="+pointY+"&Address="+address+"&siteNo="+siteNo+"&siteName="+siteName);
}
