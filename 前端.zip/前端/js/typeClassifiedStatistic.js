
    var response={};
    $(function () {

        // var start1 = getThreeDaysBeforeDate2()//当前日期的前3天
        var start1 = '2016-01-01 15:30:30'
        var end1 = getNowFormatDate2()//当前日期
        $('#date01').val(start1);
        $('#date02').val(end1);

        //动态生成页面比较
        typeClassified();
        //绑定点击事件
        $('.siteList').on('click','.checkSee',function(){
            var configNo = $(this).find('input').val();
            var start2 =$('#date01').val();
            var end2 =$('#date02').val();
        //点击跳转
            window.location.href='siteRank.html?configNo='+encodeURIComponent(configNo)+'&startTime='+encodeURIComponent(start2)+
            '&endTime='+encodeURIComponent(end2);
        })
    });
    function typeClassified() {
    $.ajax({
        url: javaUrlBase + '/config/getConfiurationTree.do',
        type: 'post',
        dataType: 'json',
        data: {},
        success: function (data) {
            response.list=data;
             console.log(response);
             var html =template('siteRankList',response);
             $('.siteList').html(html);
        }
    })
}
