
//全局变量
var configNo, word, startTime, endTime, response = {};
var useNO = 'Admin',defaultVal;
$(function () {
    //获取用户信息
    // buss.getUserInfo();
    var start1 = getThreeDaysBeforeDate2();//默认前3天时间
    console.log(start1)
    var end1 = getNowFormatDate2();//默认当天时间;
    $('#date01').val(start1);
    $('#date02').val(end1);
    startTime = $('#date01').val();//startTime
    startTime = '2016-01-01 12:10:10'
    endTime = $('#date02').val();//endTime
    getSetting();//选项

    //绑定查询事件
    $('.loginin').on('click', render)
    // render()
    //绑定维护排行事件
    $('.result').on('click', '.wrapper11', function () {
        var sendNo = $(this).find('.siteNo').find('.sendNo').html();
        window.location.href = 'siteDetail.html?sendNo=' + encodeURIComponent(sendNo)
    })

});
// 获取configNo;
function getSetting() {
    $.ajax({
        url: javaUrlBase + '/config/getConfiurationTree.do',
        type: 'post',
        dataType: 'json',
        data: {},
        success: function (data) {
            response.list = data;
            console.log(response);
            var html = template('optionsList', response);
            $('#options').html(html);//动态生成select标签  
            // defaultVal= $('#options').children('option').eq(0).val();
        },
        error: function () {

        }
    })
};
//渲染列表
function render() {
    configNo = $('select').find('option:selected').val();//configNo
    
    word = $('.word').val();//str
    $.ajax({
        type: 'post',
        data: {
            configNo: configNo,
            str: word,
            startTime: startTime,
            endTime: endTime,
            userNo: userNO,
        },
        dataType: 'json',
        url: javaUrlBase + '/backstage/getAlarmDataByCriteria.do',
        success: function (data) {
            if(!data.rows.length){
                alert('没数据');
                return false;
            }
            //处理返回数据;
            var html = template('listInfo', data);
            $('.result').html(html);

        },
        error: function () {

        }
    })
};

