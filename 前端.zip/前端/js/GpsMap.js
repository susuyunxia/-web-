//地图对象
var map;
var siteLocation;//站点位置
var userLocation;//用户位置
var distance;//用户距离
//站点对象
var site = {};
//工单对象
var dispatch = {};
//推送编号
var sendNo = "";
//误差距离
var diff = 1000;
var userNO = 'Admin'

$(function () {
    //获取用户信息
    // buss.getUserInfo();

    if (userNO != "") {
        //查询单号数据
        getDispachInfo();

        if (dispatch.dispatchNo) {
            //初始化一个地图
            initMap();
        } else {
            siteLocation = new AMap.LngLat(114.452624, 30.418269);
            //创建一个map对象
            map = new AMap.Map('AMap', {
                resizeEnable: true,
                zoom: 14,
                center: siteLocation
            });
        }

        //初始化jssdk
        weixin.initJSSDK(['getLocation', 'openLocation']);

        wx.ready(function () {
            //初始化定位
            initLoaction();
        });
    }
});

//初始化一个地图
function initMap() {
    //站点位置
    siteLocation = new AMap.LngLat(site.pointX, site.pointY);
    //创建一个map对象
    map = new AMap.Map('AMap', {
        resizeEnable: true,
        zoom: 14,
        center: siteLocation
    });

    var content = '<div><div class="marker-site">' + site.siteName + '</div><img src="./images/mark_bs.png" alt=""></div>';
    //添加一个标记点
    var marker = new AMap.Marker({
        position: siteLocation,
        content: content,
        map: map
    });

    //添加一个圆形框
    var circle = new AMap.Circle({
        center: siteLocation,
        radius: 1000,
        strokeColor: "#2291ff",
        fillColor: "#2291ff",
        fillOpacity: "0.3",
        map: map
    });
}

//初始化定位
function initLoaction() {
    wx.getLocation({
        type: 'gcj02', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
        success: function (res) {
            userLocation = new AMap.LngLat(res.longitude, res.latitude);

            //创建用户点位
            addUserLocation(userLocation);

            //渲染工单详情
            renderDispatchInfo();
        }
    });
}

//添加用户点位
function addUserLocation(userLocation) {
    //添加用户标记点
    var marker = new AMap.Marker({
        position: userLocation,
        icon: new AMap.Icon({ image: "./images/mark_user.png" }),
        map: map
    });

    //获取点列表
    var lineArr = [
        siteLocation.toString().split(','),
        userLocation.toString().split(',')
    ];
    var polyline = new AMap.Polyline({
        map: map,
        path: lineArr,            // 设置线覆盖物路径
        strokeColor: '#3366FF',   // 线颜色
        strokeOpacity: 1,         // 线透明度
        strokeWeight: 2,          // 线宽
        strokeStyle: 'solid',     // 线样式
        strokeDasharray: [10, 5], // 补充线样式
        geodesic: true            // 绘制大地线
    });

    //自适应地图缩放
    map.setFitView();
}

//导航到站点所在地
function navigate() {
    wx.openLocation({
        latitude: siteLocation.getLat(), // 纬度，浮点数，范围为90 ~ -90
        longitude: siteLocation.getLng(), // 经度，浮点数，范围为180 ~ -180。
        name: site.siteName, // 位置名
        address: site.address, // 地址详情说明
        scale: 1, // 地图缩放级别,整形值,范围从1~28。默认为最大
        infoUrl: '' // 在查看位置界面底部显示的超链接,可点击跳转
    });
}

//获取工单信息
function getDispachInfo() {
    sendNo = common.getUrlParams("sendNo", location.href);
    var params = {
        sendNo: sendNo,
        userNo: userNO
    };
    $.ajax({
        type: "post",
        url: javaUrlBase + "/backstageMaintain/dispatchManageList.do",
        data: params,
        async: false,
        dataType: "json",
        success: function (response) {
            if (response) {
                if (response.rows.length > 0) {
                    var rows = response.rows[0];
                    //工单信息
                    dispatch.dispatchNo = rows.dispatchNo;
                    dispatch.dispatchState = rows.dispatchState;
                    dispatch.configNoName = rows.configNoName;
                    //站点信息
                    site.siteNo = rows.siteNo;
                    site.siteName = rows.siteName;
                    site.address = rows.address;
                    site.pointX = rows.pointX;
                    site.pointY = rows.pointY;
                } else {
                    alert("获取工单信息失败");
                }
            }
        }
    });
}

//渲染工单详情
function renderDispatchInfo() {
    $(".siteName").text(site.siteName);
    $(".abnormalType").text(dispatch.configNoName);
    //计算距离
    distance = siteLocation.distance(userLocation);
    distance = distance.roundN(2);
    $(".distance").text(distance + "m");
}

//打卡
function signIn() {
    if (siteLocation && userLocation) {
        if (distance > diff) {
            var r = confirm("打卡位置在维护位置" + diff + "米以外，是否继续打卡？");
            if (r == false) {
                return;
            }
        }

        var params = {
            siteNo: site.siteNo,//（站点编号--微信/平台）
            userNo: userNO,//(用户编号--微信端需要传)
            sendNo: sendNo, //（订单编号）
            signedDistance: distance, //(打卡距离)
            openID: openid, //（微信openid）
            pointX: userLocation.getLng(),// （经度）
            PointY: userLocation.getLat()//（纬度）
        };

        //请求打卡
        $.ajax({
            type: "post",
            url: javaUrlBase + "/backstage/addSignedDtails.do",
            data: params,
            dataType: "json",
            success: function (response) {
                if (response.message == "打卡成功") {
                    dispatch.dispatchState = 2;
                }
                alert(response.message);
            }
        });

    } else {
        alert("定位信息未初始化");
    }
}

//跳转到处理单页面
function gotoProcessSheet() {
    if (dispatch.dispatchState == 1) {
        alert("请打卡后再填写处理单");
        return;
    }
    if (dispatch.dispatchState == 3||dispatch.dispatchState == 4) {
        alert("已填写处理单");
        return;
    }
    window.location.href = 'processSheet.html?sendNo=' + sendNo;
}