$(function () {
    //获取openid
    weixin.getOpenId();

    //登录绑定平台用户
    var options = {
        url: javaUrlBase+"/backstageMaintain/addWeiXinOpenId.do",
        type: "post",
        dataType: "json",
        beforeSubmit: function (formData, jqueryForm, options) {
            var params = {
                "name":"weiXinOpenId",
                "value":openid
            }
            formData.push(params);
        },
        success: function (data) {
            if(data){
                if(data.result){
                    alert("绑定平台用户成功");
                }else{
                    alert("绑定平台用户失败，请联系管理员");
                }
            }else{
                alert("服务维护中，请联系管理员");
            }
        },
        error: function () {
            alert("服务维护中，请联系管理员");
        }
    }

    $('#loginForm').submit(function () {
        var form = this;
        setTimeout(function () {
            $(form).ajaxSubmit(options);
        }, 1000);
        return false;
        //非常重要，如果是false，则表明是不跳转
        //在本页上处理，也就是ajax，如果是非false，则传统的form跳转。
    });
});