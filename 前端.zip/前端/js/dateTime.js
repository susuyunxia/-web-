//插件中的日历写法
    $("#date01").jeDate({
        isinitVal: true,
        //festival:true,
        ishmsVal: false,
        minDate: '2016-06-16 23:59:59',
        maxDate: $.nowDate({ DD: 0 }),
        format: "YYYY-MM-DD hh:mm:ss",
        zIndex: 3000,
    })
    $("#date02").jeDate({
        isinitVal: true,
        //festival:true,
        ishmsVal: false,
        minDate: '2016-06-16 23:59:59',
        maxDate: $.nowDate({ DD: 0 }),
        format: "YYYY-MM-DD hh:mm:ss",
        zIndex: 3000,
    })