$(function () {
    //获取用户信息
    buss.getUserInfo();
    userNO = "Admin"
    if (userNO != "") {
        //获取用户工单
        var list = getUserDispach();
    }

    //绑定项目
    $(document).on("click", ".each", jumpToMap);
});

//获取用户工单
function getUserDispach() {
    var params = {
        userNo: userNO
    };

    $.ajax({
        type: "post",
        url: javaUrlBase + "/backstageMaintain/dispatchManageListWeiXin.do",
        data: params,
        dataType: "json",
        success: function (response) {
            if (response) {
                var html = template("dispatchList", { "item": response.rows });
                $(".root").html(html);
            } else {
                alert("服务异常，请联系管理员");
            }
        }
    });
}

//页面跳转
function jumpToMap() {
    var sendNo = $(this).data("sendno");
    window.location.href = "GpsMap.html?sendNo=" + sendNo;
}
