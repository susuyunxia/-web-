﻿/**============================================================================================
**创建说明:前端公共函数类
**创建人  :lichen
**创建时间:2017-3-16           
==============================================================================================*/
var common;//公共对象
window.common = {};

//.net基础URL
var netUrlBase = "http://zhhzpt.newfiber.com.cn/HTGL"
//java基础URL
var javaUrlBase = "http://120.77.215.143:6008";
// var javaUrlBase = "http://192.168.16.55:8091";
//应用程序虚拟目录
var VD = "/HTGL";

//获取url中的指定参数
common.getUrlParams = function (name, url, win) {
	var r;
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	if (url == undefined || url == null || url == "") {
		if (win == undefined || win == null || win == "")
			r = window.location.search.substr(1).match(reg);
		else
			r = win.location.search.substr(1).match(reg);
	} else {
		if (url.indexOf('?') > -1)
			r = url.split('?')[1].match(reg);
		else
			r = url.match(reg);
	}
	if (r != null) {
		return r[2];
	}
}


//获取根目录
common.getRoot = function (url) {
	if (!url) {
		url = location.href;
	}
	return url.substring(0, url.indexOf("/pages/"));
}

//获取虚拟目录
common.getVD = function (url) {
	var arr = common.getRoot(url).split('/');
	var len = arr.length;
	if (len < 4) {
		return "";
	} else {
		return "/" + arr[len - 1];
	}
}

//获取端口号
common.getPort = function (url) {
	var root = common.getRoot(url);
	var VD = common.getVD(url); 
	var rootNoVD = ""
	if (VD != "") {
		rootNoVD = root.substring(0, root.indexOf(VD));
	} else {
		rootNoVD = root;
	}
	var port = "80";
	if (rootNoVD.split(":").length >= 3) {
		port = rootNoVD.substr(rootNoVD.lastIndexOf(":") + 1);
	}
	return port;
}

//原型扩展
//数组里面最大值/最小值
Array.prototype.max = function () {
	return Math.max.apply({}, this);
}

Array.prototype.min = function () {
	return Math.min.apply({}, this);
}

//时间格式化
Date.prototype.format = function (mask) {
	var d = this;
	var zeroize = function (value, length) {
		if (!length) length = 2;
		value = String(value);
		for (var i = 0, zeros = ''; i < (length - value.length); i++) {
			zeros += '0';
		}
		return zeros + value;
	};

	return mask.replace(/"[^"]*"|'[^']*'|\b(?:d{1,4}|m{1,4}|yy(?:yy)?|([hHMstT])\1?|[lLZ])\b/g, function ($0) {
		switch ($0) {
			case 'd': return d.getDate();
			case 'dd': return zeroize(d.getDate());
			case 'ddd': return ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'][d.getDay()];
			case 'dddd': return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d.getDay()];
			case 'M': return d.getMonth() + 1;
			case 'MM': return zeroize(d.getMonth() + 1);
			case 'MMM': return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()];
			case 'MMMM': return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][d.getMonth()];
			case 'yy': return String(d.getFullYear()).substr(2);
			case 'yyyy': return d.getFullYear();
			case 'h': return d.getHours() % 12 || 12;
			case 'hh': return zeroize(d.getHours() % 12 || 12);
			case 'H': return d.getHours();
			case 'HH': return zeroize(d.getHours());
			case 'm': return d.getMinutes();
			case 'mm': return zeroize(d.getMinutes());
			case 's': return d.getSeconds();
			case 'ss': return zeroize(d.getSeconds());
			case 'l': return zeroize(d.getMilliseconds(), 3);
			case 'L': var m = d.getMilliseconds();
				if (m > 99) m = Math.round(m / 10);
				return zeroize(m);
			case 'tt': return d.getHours() < 12 ? 'am' : 'pm';
			case 'TT': return d.getHours() < 12 ? 'AM' : 'PM';
			case 'Z': return d.toUTCString().match(/[A-Z]+$/);
			// Return quoted strings with the surrounding quotes removed
			default: return $0.substr(1, $0.length - 2);
		}
	});
};

//四舍五入
Number.prototype.roundN = function (e) {
	var t = 1;
	for (; e > 0; t *= 10, e--);
	for (; e < 0; t /= 10, e++);
	return Math.round(this * t) / t;
}


/**============================================================================================
**创建说明:微信开发函数类
**创建人  :lichen
**创建时间:2017-8-25           
==============================================================================================*/
var weixin;
window.weixin = {};

//openid
var openid = "";

//获取openid
weixin.getOpenId = function () {
	//读取localStorage中openid
	openid = localStorage.getItem("openid");
	if (openid == "" || openid == null) {
		//为空时读取url后面的openid
		var urlOpenid = common.getUrlParams('openid', location.href);
		if (!urlOpenid || urlOpenid == "") {
			//url参数为空，页面跳转发请求
			location.href = netUrlBase + "/OAuth/OAuthPage?returnUrl=" + encodeURI(location.href);
			return false;
		} else {
			//写localStorage
			localStorage.setItem("openid", urlOpenid);
			openid = urlOpenid;
		}
	}
	return true;
}

//初始化jssdk
weixin.initJSSDK = function (apiList, isDebug) {
	//默认不调试
	if (isDebug == null) {
		isDebug = false;
	}

	$.ajax({
		type: "post",
		url: netUrlBase + "/JSSDK/GetJSSDKConfig",
		data: { returnURL: location.href },
		dataType: "json",
		success: function (response) {
			//配置微信jssdk
			wx.config({
				debug: isDebug, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
				appId: response.AppId, // 必填，公众号的唯一标识
				timestamp: response.Timestamp, // 必填，生成签名的时间戳
				nonceStr: response.NonceStr, // 必填，生成签名的随机串
				signature: response.Signature, // 必填，签名，见附录1
				jsApiList: apiList // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
			});
		}
	});
}

/**============================================================================================
**创建说明:后台管理系统微信公共函数
**创建人  :lichen
**创建时间:2017-8-31           
==============================================================================================*/
var buss;
window.buss = {};

//平台用户编号
var userNO = "";

//验证用户绑定
buss.checkUserBinding = function () {
	var params = {
		weiXinOpenId: openid
	}
	$.ajax({
		type: "post",
		url: javaUrlBase + "/backstageMaintain/selectWeiXinOpenIdById.do",
		data: params,
		async: false,
		dataType: "json",
		success: function (response) {
			if (response) {
				if (response.success == "查询成功"&&response.data!=undefined) {
					if (response.data.openIdState == 1) {
						//赋值用户编号给全局变量
						userNO = response.data.userNo;
					}
					if (response.data.openIdState == 2) {
						//用户已解绑，跳转登录页面
						window.location.href = common.getRoot() + "/pages/login.html";
					}
				} else {
					//用户未绑定
					window.location.href = common.getRoot() + "/pages/login.html";
				}
			} else {
				buss.authError();
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			buss.authError();
		}
	});
}

//获取用户信息
buss.getUserInfo = function () {
	var res = weixin.getOpenId();
	if (res) {
		buss.checkUserBinding();
	}
}

//身份验证错误
buss.authError = function () {
	window.location.href = common.getRoot() + "/pages/authenticationFailure.html";
}

//用户权限错误
buss.permisError = function () {
	window.location.href = common.getRoot() + "/pages/permissionError.html";
}
