$(function () {
    var configNo = "";

    //获取配置类型编号
    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/getConfiurationTree.do",
        dataType: "json",
        success: function (response) {
            if (response) {
                //遍历json数组，查找因子无变化的配置编号
                $(response).each(function (i, e) {
                    if (e.configName == "同一站点数据无变化维护") {
                        configNo = e.configNo;
                    }
                });

                $.ajax({
                    type: "post",
                    url: javaUrlBase + "/config/getConfigurationByConfigNo.do",
                    data: { "configNo": configNo },
                    dataType: "json",
                    success: function (response) {
                        if (response.rows.length) {
                            $('#dayValue').val(response.rows[0].fieldDayValue);
                            
                        }
                        //获取到所有的因子无变化配置
                            var html = template('liList', { "item": response.rows });
                            $("#fieldList").html(html);

                    }
                });
            }
        }
    });

    //绑定添加按钮
    $("#add-page").on("click", function () {
        var dayValue = $("#dayValue").val();
        if (dayValue == "") {
            alert("天数不能为空");
            $("#dayValue").focus();
            return;
        }
        window.location.href = "addFavor.html?dayValue=" + dayValue;
    });
});