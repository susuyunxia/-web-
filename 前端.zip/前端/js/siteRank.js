//全局变量
var response = {}, total = 0;
var arr1 = [];
var Request = new UrlSearch(); //实例化url中的地址参数对象
var start1 = decodeURIComponent(Request.startTime);//开始时间
var end1 = decodeURIComponent(Request.endTime);//结束时间
var configNo = decodeURIComponent(Request.configNo);//
var userNO='admin'
$(function () {
    // buss.getUserInfo();//获取用户信息
    render();//渲染页面
});
//读取数据并渲染页面
function render() {
    $.ajax({
        type: 'post',
        data: {
            configNo: configNo,
            startTime: start1,
            endTime: end1,
            userNo: userNO
        },
        dataType: 'json',
        url: javaUrlBase + '/backstage/getSiteOrderByConfigNo.do',
        success: function (data) {
            response.list = data;
            console.log(data);
            $(data).each(function (i, v) {
                arr1.push(v.count);
                total += v.count
            });
            $('.total').html(total)
            if (data.length) {
                pin(arr1) //渲染饼状图
                console.log(response);
                //处理返回数据;
                var html = template('listInfo', response);
                $('.rank').html(html)
            }
            else{
                 $('.total').html("0")
                var arr2 =[1,2,2,3,4]
                pin(arr2) //渲染饼状图
            }

        },
        error: function () {

        }
    })
}
//饼图
function pin(arr) {
    var myChart = echarts.init(document.getElementById('pin'));//饼图
    option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
            {
                type: 'pie',
                radius: ['50%', '62%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '30',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: arr
            }
        ]
    };

    myChart.setOption(option);


}