$(function () {
    var configNo = "";

    //获取配置类型编号
    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/getConfiurationTree.do",
        dataType: "json",
        success: function (response) {
            if (response) {
                //遍历json数组，查找因子无变化的配置编号
                $(response).each(function (i, e) {
                    if (e.configName == "同一站点数据无变化维护") {
                        configNo = e.configNo;
                    }
                });

                $.ajax({
                    type: "post",
                    url: javaUrlBase + "/config/getConfigurationByConfigNo.do",
                    data: { "configNo": configNo },
                    dataType: "json",
                    success: function (response) {
                        //获取到所有的因子无变化配置
                        var html = template('imgshow', { "item": response.rows });
                        $(".addList").html(html);
                    }
                });
            }
        }
    });

    //绑定添加按钮
    $("#btn-del").on("click", deleteField);
});

//删除因子
function deleteField() {
    var params = {
        serials: []
    };
    $('input:checkbox').each(function () {
        if ($(this).prop('checked') == true) {
            params.serials.push($(this).data("serial"));
        }
    });

    if (params.serials.length == 0) return;

    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/deletePropertyBySerial.do",
        data: $.param(params, true),
        dataType: "json",
        success: function (response) {
            alert(response.message);
        }
    });
}