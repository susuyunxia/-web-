$(function () {
    //获取用户信息
    // buss.getUserInfo();
    var userNO='Admin'
    if (userNO != "") {
        //通过用户编号查询是否有权限进行配置
        var params = {
            User_No: userNO,
            Jurisdiction_Name: "微信维护配置"
        }
        $.ajax({
            type: "post",
            url: javaUrlBase + "/WerXinJurisd.do",
            data: params,
            dataType: "json",
            success: function (response) {
                if (response) {
                    if (response.result) {
                        //渲染菜单
                    } else {
                        buss.permisError();
                    }
                } else {
                    buss.permisError();
                }
            },
            error: function () {
                //权限错误
                buss.permisError();
            }
        });
    }

});
