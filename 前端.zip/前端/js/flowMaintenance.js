//配置编号
var configNo = "";
//记录主键
var serial1 = 0, serial2 = 0;
var userNO='Admin'
$(function () {
    //读取用户信息
    // buss.getUserInfo();

    if (userNO != "") {
        //读取流量异常配置
        getSetting();
        //绑定确定按钮
        $("#btnConfig").on("click", updateConfig);
    }

});

//读取流量异常配置
function getSetting() {
    //获取配置类型编号
    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/getConfiurationTree.do",
        dataType: "json",
        success: function (response) {
            if (response) {
                //遍历json数组，查找因子无变化的配置编号
                $(response).each(function (i, e) {
                    if (e.configName == "流量维护") {
                        configNo = e.configNo;
                    }
                });

                $.ajax({
                    type: "post",
                    url: javaUrlBase + "/config/getConfigurationByConfigNo.do",
                    data: { "configNo": configNo },
                    dataType: "json",
                    success: function (response) {
                        //赋值配置
                        $(response.rows).each(function (i, e) {
                            if (e.fieldName == "Z") {
                                serial1 = e.serial;
                                $("#check1").attr("checked", "checked");
                                $("#fieldDayValue").val(e.fieldDayValue);
                                $("#fieldValue1").val(e.fieldValue);
                                $("#fieldAlarmValue1").val(e.fieldAlarmValue);
                            }
                            if (e.fieldName == "ZB") {
                                serial2 = e.serial;
                                $("#check2").attr("checked", "checked");
                                $("#fieldDayValue").val(e.fieldDayValue);
                                $("#fieldValue2").val(e.fieldValue);
                                $("#fieldAlarmValue2").val(e.fieldAlarmValue);
                            }
                        });
                    }
                });
            }
        }
    });
}

//配置流量异常值
function updateConfig() {
    var check1 = $("#check1").prop("checked");
    var check2 = $("#check2").prop("checked");
    var params = {
        serial: [],//（主键编号）
        fieldName: [],//（因子名称--Z或者ZB）
        fieldNameZN: [],//（因子中文名称--水位1、水位2）
        fieldValue: [],//（水位大于的值）
        fieldAlarmValue: [],//（流速值）
        fieldAlarmFieldName: [],//（流速名称--VA、VJ）
        dayValue: $("#fieldDayValue").val(),//（持续天数）
        fieldStrValue: ">",//（大于符号>）
        configNo: configNo,//(异常编号)
        configName: "流量维护",//（异常名称）
        userNo: userNO//(用户编号)
    };
    if (check1) {
        params.serial.push(serial1);
        params.fieldName.push("Z");
        params.fieldNameZN.push("水位1");
        params.fieldValue.push($("#fieldValue1").val());
        params.fieldAlarmValue.push($("#fieldAlarmValue1").val());
        params.fieldAlarmFieldName.push("VA");
    }
    if (check2) {
        params.serial.push(serial2);
        params.fieldName.push("ZB");
        params.fieldNameZN.push("水位2");
        params.fieldValue.push($("#fieldValue2").val());
        params.fieldAlarmValue.push($("#fieldAlarmValue2").val());
        params.fieldAlarmFieldName.push("VJ");
    }

    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/updateFlowConfig.do",
        data: $.param(params, true),
        dataType: "json",
        success: function (response) {
            if (response) {
                alert(response.message);
            }
        }
    });
}