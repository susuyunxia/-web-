//派单编号
var sendNo = ""
//巡检单对象
var inspection = {};
//上传照片总数
var imgCanChoose = 3;
//图片url数组
var pics = [];
//巡检id
var routingId = "";

$(function () {
    //用户信息
    buss.getUserInfo();
    if (userNO != "") {
        //查询工单信息
        getRoutingInfo();
    }

    //初始化jssdk
    weixin.initJSSDK(['chooseImage', 'previewImage', 'uploadImage']);

    //绑定上传图片按钮
    $("#btn-upload").on("click", wxChooseImage);

    //绑定表单提交
    $("#btn-submit").on("click", submitProcessSheet);
});

//拍照或从手机相册中选图接口
function wxChooseImage() {
    if (imgCanChoose < 1) {
        alert("只能选择3张图片", "forbidden");
        return;
    }
    wx.chooseImage({
        count: imgCanChoose,
        needResult: 1,
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        success: function (data) {
            localIds = data.localIds; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
            if (localIds && localIds.length > 0) {
                var mediaIds = [];
                var localIds1 = [];
                //上传图片
                wxuploadImage(localIds, localIds1, mediaIds);
            }
        },
        fail: function (res) {
            //错误
        }

    });
}

//上传图片
function wxuploadImage(localIds, localList, mediaList) {
    var valLocalList = localList;
    var valMediaList = mediaList;
    var localId = localIds.pop()
    wx.uploadImage({
        localId: localId, // 需要上传的图片的本地ID，由chooseImage接口获得
        isShowProgressTips: 1, // 默认为1，显示进度提示
        success: function (res) {
            var mediaId = res.serverId; // 返回图片的服务器端ID
            if (mediaId && mediaId != "") {
                valMediaList.push(mediaId);
                valLocalList.push(localId);
            }
            if (localIds.length > 0) {
                wxuploadImage(localIds, valLocalList, valMediaList);
            } else {
                //显示缩略图
                showImgs(valLocalList, valMediaList);
            }
        },
        fail: function (error) {
            //失败
            console.log("上传失败");
        }
    });
}

//显示缩略图
function showImgs(localIds, mediaIds) {
    var imgCount = $("#imgList").find("img").length;
    if (imgCount < 3) {
        var html = "";
        localIds.forEach((localId, index, arr) => {
            html += '<img src="' + localId + '" class="showPIC" data-mediaID="' + mediaIds[index] + '"/>';
        });
        $("#imgList").append(html);

        //下载到自己服务器并替换缩略图url
        downToMyServer(mediaIds);

        //单击进行预览
        $("#imgList .showPIC").off("click").on("click", function () {
            prewPic(this);
        });
    }
}

//下载到自己服务器,并替换httpUrl
function downToMyServer(mediaIds) {
    var param = {
        "mediaIds": mediaIds
    };
    $.ajax({
        type: "post",
        url: common.getRoot() + "/JSSDK/DownImgFromWX",
        data: param,
        dataType: "json",
        async: false,
        success: function (response) {
            if (response && response != "") {
                //返回格式["mediaId":"url","mediaId":"url"]
                //替换url为http url
                $.each(response, (i) => {
                    replaceImgUrl(i, response[i]);
                })
            }
        }
    });

    imgCanChoose -= mediaIds.length;
}

//替换图片url，由localId替换为Http Url,以实现预览功能
function replaceImgUrl(mediaId, url) {
    $("[data-mediaid=" + mediaId + "]").attr("src", VD + url);
}

//预览图片
function prewPic(elem) {
    var currUrl = $(elem).prop("src");
    var urlList = $("#imgList .showPIC");
    var urlListFinal = [];
    $(urlList).each(function (index, item) {
        var urlItem = $(item).prop("src");
        urlListFinal.push(urlItem);
    });

    wx.previewImage({
        current: currUrl,
        urls: urlListFinal
    });
}

//查询工单信息
function getRoutingInfo() {
    routingId = common.getUrlParams("routingId", decodeURI(location.href));
    $("#siteNo").val(common.getUrlParams("siteNo", decodeURI(location.href)));//站点编号
    $("#siteName").val(common.getUrlParams("siteName", decodeURI(location.href)));//站点名称
    $("#time").val(new Date().format("yyyy-MM-dd HH:mm:ss"));
    $("#userNo").val(userNO);
}



// 提交工作处理单
function submitProcessSheet() {
    var params = {
        siteNo: $("#siteNo").val(),//站点编号,
        routingContent: $("#routingContent").val(),//巡检内容
        userNo: userNO,//用户编号
        pics: null,//图片数组
        weiXinOpenId: openid,
        routingId: routingId
    }

    var urlList = $("#imgList .showPIC");
    if (urlList.length > 0) {
        var urlListFinal = [];
        $(urlList).each(function (index, item) {
            var urlItem = $(item).attr("src");
            urlItem = urlItem.replace(VD, "");
            urlListFinal.push(urlItem);
        });

        params.pics = urlListFinal;
    }

    $.ajax({
        type: "post",
        url: javaUrlBase + "/backstageMaintain/addWeiXinRoutingMessage.do",
        data: $.param(params, true),
        dataType: "json",
        success: function (response) {
            alert(response.message);
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert(textStatus);
        }
    });

}
