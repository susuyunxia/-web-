//配置编号
var configNo = "";
//记录主键
var serial1 = 0, serial2 = 0;

$(function () {
    //读取用户信息
    buss.getUserInfo();
    if (userNO != "") {
        //读取流量异常配置
        getSetting();
        //绑定确定按钮
        $("#btnConfig").on("click", updateConfig);
    }

});

//读取流量异常配置
function getSetting() {
    //获取配置类型编号
    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/getConfiurationTree.do",
        dataType: "json",
        success: function (response) {
            if (response) {
                //遍历json数组，查找因子无变化的配置编号
                $(response).each(function (i, e) {
                    if (e.configName == "水位计跳动维护") {
                        configNo = e.configNo;
                    }
                });

                $.ajax({
                    type: "post",
                    url: javaUrlBase + "/config/getConfigurationByConfigNo.do",
                    data: { "configNo": configNo },
                    dataType: "json",
                    success: function (response) {
                        if (response) {
                            $(response.rows).each(function (i, e) {
                                if (e.fieldName == "Z") {
                                    serial1 = e.serial;
                                    $("#check1").attr("checked", "checked");
                                    $("#fieldStrValue").val(e.fieldStrValue);
                                    $("#dayValue").val(e.fieldDayValue);
                                    $("#fieldAlarmValue").val(e.fieldAlarmValue);
                                    $("#fieldValue1").val(e.fieldValue);
                                }
                                if (e.fieldName == "ZB") {
                                    serial2 = e.serial;
                                    $("#check2").attr("checked", "checked");
                                    $("#fieldStrValue").val(e.fieldStrValue);
                                    $("#dayValue").val(e.fieldDayValue);
                                    $("#fieldAlarmValue").val(e.fieldAlarmValue);
                                    $("#fieldValue2").val(e.fieldValue);
                                }
                            });
                        }
                    }
                });
            }
        }
    });
}

//配置流量异常值
function updateConfig() {
    var check1 = $("#check1").prop("checked");
    var check2 = $("#check2").prop("checked");
    var params = {
        serial1: serial1,//（水位计1的主键id，如果查询出来为0，则传参时不需要赋值）
        serial2: serial2,//（水位计2的主键id，如果查询出来为0，则传参时不需要赋值）
        filedValue1: $("#fieldValue1").val(),//（水位计1的水位值）
        filedValue2: $("#fieldValue2").val(),//（水位计2的水位值）
        fieldStrValue: $("#fieldStrValue").val(),//（次数）
        dayValue: $("#dayValue").val(),//（时间/小时）
        fieldAlarmValue: $("#fieldAlarmValue").val(),//（相邻值）
        fieldName: "Z",//（字段属性：Z）
        fieldNameZn: "水位计1",//(字段名称：水位计1)
        configNo: configNo,//（异常编号）
        configName: "水位计跳动维护配置",//（异常名称）
        checkedBoxZ: check1,//（水位计1是否被勾选，勾选：true，未勾选：false）
        checkedBoxZB: check2,//（水位计2是否被勾选，勾选：true，未勾选：false）
        fieldName2: "ZB",//（字段属性：ZB）
        fieldNameZn2: "水位计2",//（字段名称：水位计2）
        userNo: userNO//(用户编号)
    };
    $.ajax({
        type: "get",
        url: javaUrlBase + "/config/updateWaterLevelConfig.do",
        data: $.param(params, true),
        dataType: "json",
        success: function (response) {
            if (response) {
                alert(response.message);
            }
        }
    });
}