$(function(){
    //获取openid
    weixin.getOpenId();

    //解绑平台用户
    var options = {
        url: "",
        type: "post",
        dataType: "json",
        beforeSubmit: function(){

        },
        success: function (data) {
            
        },
        error: function () {
            
        }
    }

    $('#unbindForm').submit(function () {
        var form = this;
        setTimeout(function () {
            $(form).ajaxSubmit(options);
        }, 1000);
        return false;
        //非常重要，如果是false，则表明是不跳转
        //在本页上处理，也就是ajax，如果是非false，则传统的form跳转。
    });
        
});