
// 全局变量
var response = {}, arr1 = [], total = 0;
var Request = new UrlSearch(); //实例化url中的地址参数对象
var startTime = decodeURIComponent(Request.startTime);//开始时间
var endTime = decodeURIComponent(Request.endTime);//结束时间
var siteNo = decodeURIComponent(Request.siteNo);//
$(function () {
    // buss.getUserInfo();//获取用户信息
    render();//渲染页面

});
//读取数据
function render() {
    $.ajax({
        type: 'post',
        data: {
            siteNo: siteNo,
            startTime: startTime,
            endTime: endTime
        },
        dataType: 'json',
        url: javaUrlBase + '/backstage/getAlarmOrderBySiteNo.do',
        success: function (data) {
            response.list = data;
            console.log(data);
            $(data).each(function (i, v) {
                arr1.push(v.count);
                total += v.count;
            });
            console.log(arr1);
            console.log(response);
            $('.total').html(total);
            
            //处理返回数据;
            if (response.list.length) {
                pin(arr1) //渲染饼图
                var html = template('listInfo', response);
                $('.rank').html(html);
            }
            else{
                var arr2 = [1,1,1,1,1];
                pin(arr2) //渲染饼图
                var html2 = template('data0', response);
                $('.rank').html(html2);

            }
        },
        error: function () {

        }
    });
}
// 饼图
function pin(arr) {
    var myChart = echarts.init(document.getElementById('pin'));//饼图
    option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
            {
                type: 'pie',
                radius: ['50%', '62%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '30',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: arr
            }
        ]
    };

    myChart.setOption(option);


}

