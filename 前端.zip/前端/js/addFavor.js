
var configNo = "";
var userNO = 'Admin'

$(function () {
    // buss.getUserInfo();
    if(userNO=="") return;
    //读取未配置因子列表
    getUnConfigList();

    //绑定添加按钮
    $("#btn-add").on("click", addField);
});

function getUnConfigList() {


    //获取配置类型编号
    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/getConfiurationTree.do",
        dataType: "json",
        success: function (response) {
            if (response) {
                //遍历json数组，查找因子无变化的配置编号
                $(response).each(function (i, e) {
                    if (e.configName == "同一站点数据无变化维护") {
                        configNo = e.configNo;
                    }
                });

                $.ajax({
                    type: "post",
                    url: javaUrlBase + "/config/getNotConfigProperty.do",
                    data: { "configNo": configNo },
                    dataType: "json",
                    success: function (response) {
                        //获取到所有的因子无变化配置
                        var html = template('imgshow', { "item": response.rows });
                        $(".addList").html(html);
                    }
                });
            }
        }
    });
}

//添加因子
function addField() {
    var params = {
        propertyNo: [], //（添加的因子的编号，为之前传过来的code_ASCII）
        configNo: configNo, //（异常编号）
        configName: "同一站点数据无变化维护",//（异常名称）
        userNo: userNO,//(用户编号)
        dayValue:common.getUrlParams("dayValue",location.href)
    };
    $('input:checkbox').each(function () {
        if ($(this).prop('checked') == true) {
            params.propertyNo.push($(this).parent().next().find(".code").text());
        }
    });

    if(params.propertyNo.length==0) return;

    $.ajax({
        type: "post",
        url: javaUrlBase+"/config/addConstantFactor.do",
        data: $.param(params,true),
        dataType: "json",
        success: function (response) {
            alert(response.message);
            
        }
    });
}
var configNo = "";
var userNO = 'Admin'

$(function () {
    // buss.getUserInfo();
    if(userNO=="") return;
    //读取未配置因子列表
    getUnConfigList();

    //绑定添加按钮
    $("#btn-add").on("click", addField);
});

function getUnConfigList() {


    //获取配置类型编号
    $.ajax({
        type: "post",
        url: javaUrlBase + "/config/getConfiurationTree.do",
        dataType: "json",
        success: function (response) {
            if (response) {
                //遍历json数组，查找因子无变化的配置编号
                $(response).each(function (i, e) {
                    if (e.configName == "同一站点数据无变化维护") {
                        configNo = e.configNo;
                    }
                });

                $.ajax({
                    type: "post",
                    url: javaUrlBase + "/config/getNotConfigProperty.do",
                    data: { "configNo": configNo },
                    dataType: "json",
                    success: function (response) {
                        //获取到所有的因子无变化配置
                        var html = template('imgshow', { "item": response.rows });
                        $(".addList").html(html);
                    }
                });
            }
        }
    });
}

//添加因子
function addField() {
    var params = {
        propertyNo: [], //（添加的因子的编号，为之前传过来的code_ASCII）
        configNo: configNo, //（异常编号）
        configName: "同一站点数据无变化维护",//（异常名称）
        userNo: userNO,//(用户编号)
        dayValue:common.getUrlParams("dayValue",location.href)
    };
    $('input:checkbox').each(function () {
        if ($(this).prop('checked') == true) {
            params.propertyNo.push($(this).parent().next().find(".code").text());
        }
    });

    if(params.propertyNo.length==0) return;

    $.ajax({
        type: "post",
        url: javaUrlBase+"/config/addConstantFactor.do",
        data: $.param(params,true),
        dataType: "json",
        success: function (response) {
            alert(response.message);
            
        }
    });
}